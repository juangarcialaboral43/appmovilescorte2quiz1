package com.example.appadaptadores;

public class Usuario {
    private String nombre;
    private String url;

    public Usuario(String nombre, String url) {
        this.nombre = nombre;
        this.url = url;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUrl() {
        return url;
    }
}
