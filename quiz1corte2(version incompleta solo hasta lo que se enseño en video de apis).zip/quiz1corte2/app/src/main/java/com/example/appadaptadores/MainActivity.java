package com.example.appadaptadores;

import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView rcv_usuarios;
    List<Usuario> listaUsuarios = new ArrayList<>();//tnego un error en ususario arreglalo
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void cargarInformacion (){
        String url = "https://pokeapi.co/api/v2/pokemon/";

        StringRequest myRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    procesarRespuesta(new JSONObject(response));
                } catch (JSONException e) {
                    Toast.makeText(MainActivity.this,"Error en el servidor intente mas tarde",Toast.LENGTH_LONG).show();
                    //throw new RuntimeException(e);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {

            }
        });

        RequestQueue rq = Volley.newRequestQueue(getApplicationContext());
        rq.add(myRequest);

    }

    private void procesarRespuesta(JSONObject respuesta) {
        try {
            for (int i=0; i< respuesta.getJSONArray("results").length(); i++){
                String nombre = respuesta.getJSONArray("results").getJSONObject(i).getString("name");
                String url = respuesta.getJSONArray("results").getJSONObject(i).getString("url");
                //tnego un error en ususario arreglalo
                Usuario usu= new Usuario(nombre,url);

                listaUsuarios.add(usu);
                //error
                rcv_usuarios.setLayoutManager(new LinearLayoutManager(this));
                //error
                rcv_usuarios.setAdapter(new UsuarioAdatador(listaUsuarios));
            }
        } catch (JSONException e) {
            //throw new RuntimeException(e);
            Toast.makeText(MainActivity.this,"Error en el servidor intente mas tarde",Toast.LENGTH_LONG).show();
        }
    }

}