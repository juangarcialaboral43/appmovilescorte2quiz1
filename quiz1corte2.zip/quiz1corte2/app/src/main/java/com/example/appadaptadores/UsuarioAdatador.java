package com.example.appadaptadores;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;
import java.util.Locale;

public class UsuarioAdatador
        extends RecyclerView.Adapter<UsuarioAdatador.UsuarioViewHolder> {

    private List<Usuario> listaUsuarios;

    public UsuarioAdatador(List<Usuario> listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }

    @NonNull
    @Override
    public UsuarioViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {

        View vista = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_usuario, parent, false);

        return new UsuarioViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(
            @NonNull UsuarioViewHolder holder, int position) {

        Usuario usuario = listaUsuarios.get(position);

        String nombre = usuario.getNombre();
        holder.txtNombre.setText(
                nombre.substring(0, 1).toUpperCase(Locale.ROOT)
                        + nombre.substring(1));

        holder.txtNumero.setText(
                String.format(Locale.getDefault(),
                        "POKÉMON #%03d", position + 1));

        // Obtener el ID a partir de la URL de la API
        String url = usuario.getUrl();
        String[] partes = url.split("/");
        String id = partes[partes.length - 1];

        String imagenUrl =
                "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/"
                        + id + ".png";

        Glide.with(holder.itemView.getContext())
                .load(imagenUrl)
                .placeholder(android.R.drawable.ic_menu_gallery)
                .error(android.R.drawable.ic_menu_report_image)
                .into(holder.imgPokemon);
    }

    @Override
    public int getItemCount() {
        return listaUsuarios.size();
    }

    public static class UsuarioViewHolder
            extends RecyclerView.ViewHolder {

        ImageView imgPokemon;
        TextView txtNombre, txtNumero;

        public UsuarioViewHolder(@NonNull View itemView) {
            super(itemView);

            imgPokemon = itemView.findViewById(R.id.imgPokemon);
            txtNombre = itemView.findViewById(R.id.txtNombre);
            txtNumero = itemView.findViewById(R.id.txtNumero);
        }
    }
}
