package com.example.appadaptadores;

import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView rcv_usuarios;
    List<Usuario> listaUsuarios = new ArrayList<>();
    UsuarioAdatador adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main), (v, insets) -> {
                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars());
                    v.setPadding(systemBars.left, systemBars.top,
                            systemBars.right, systemBars.bottom);
                    return insets;
                });

        // Inicializar RecyclerView
        rcv_usuarios = findViewById(R.id.rcv_usuarios);
        rcv_usuarios.setLayoutManager(
                new LinearLayoutManager(this));

        adaptador = new UsuarioAdatador(listaUsuarios);
        rcv_usuarios.setAdapter(adaptador);

        // Cargar los Pokémon
        cargarInformacion();
    }

    private void cargarInformacion() {
        String url = "https://pokeapi.co/api/v2/pokemon/?limit=6";

        StringRequest myRequest = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            procesarRespuesta(new JSONObject(response));
                        } catch (JSONException e) {
                            Toast.makeText(MainActivity.this,
                                    "Error al procesar la información",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this,
                                "Error de conexión. Intenta nuevamente",
                                Toast.LENGTH_LONG).show();
                    }
                });

        RequestQueue rq = Volley.newRequestQueue(this);
        rq.add(myRequest);
    }

    private void procesarRespuesta(JSONObject respuesta) {
        try {
            listaUsuarios.clear();

            for (int i = 0;
                 i < respuesta.getJSONArray("results").length();
                 i++) {

                String nombre = respuesta.getJSONArray("results")
                        .getJSONObject(i).getString("name");

                String url = respuesta.getJSONArray("results")
                        .getJSONObject(i).getString("url");

                Usuario usu = new Usuario(nombre, url);
                listaUsuarios.add(usu);
            }

            // Actualizar la lista una sola vez
            adaptador.notifyDataSetChanged();

        } catch (JSONException e) {
            Toast.makeText(MainActivity.this,
                    "Error al leer los Pokémon",
                    Toast.LENGTH_LONG).show();
        }
    }
}